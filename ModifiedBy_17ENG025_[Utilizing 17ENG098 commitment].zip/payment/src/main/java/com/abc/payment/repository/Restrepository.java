package com.abc.payment.repository;

import com.abc.payment.model.RestModel;
import org.springframework.data.repository.CrudRepository;

public interface Restrepository extends CrudRepository<RestModel, Integer> {

}
