package com.abc.staff.repository;

import com.abc.staff.model.RestModel;
import org.springframework.data.repository.CrudRepository;

public interface Restrepository extends CrudRepository<RestModel, Integer> {
}
