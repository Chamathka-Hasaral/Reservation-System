package com.abc.rest.services;

import com.abc.rest.model.RestModel;
import com.abc.rest.repository.Restrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RestServices {

    @Autowired
    private Restrepository restRepository;
    public RestModel addBLMethod(RestModel restModel) {
        return restRepository.save(restModel);
    }

    public Iterable<RestModel> findAll(){
        return restRepository.findAll();
    }

    public RestModel findById(Integer id){
        return restRepository.findById(id).orElse(null);
    }

    public void delete (RestModel restModel)
    {restRepository.delete(restModel);}
}
