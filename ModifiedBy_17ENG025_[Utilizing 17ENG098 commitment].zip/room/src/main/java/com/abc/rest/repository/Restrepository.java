package com.abc.rest.repository;

import com.abc.rest.model.RestModel;
import org.springframework.data.repository.CrudRepository;

public interface Restrepository extends CrudRepository<RestModel, Integer> {

}
