package com.abc.rest.model;
import javax.persistence.*;

@Entity
@Table(name="room_details")
public class RestModel {

    @Id
    @Column(name="room_no")
    //@GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRoom_type() {
        return room_type;
    }

    public void setRoom_type(String room_type) {
        this.room_type = room_type;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Boolean getAvailability() {
        return availability;
    }

    public void setAvailability(Boolean availability) {
        this.availability = availability;
    }

    private String room_type;
    private String price;
    private Boolean availability;



    public RestModel() {
    }




}
